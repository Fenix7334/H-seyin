
import React from "react";
import { Button } from "@/components/ui/button";

export default function SosyalBoost() {
  return (
    <div className="bg-black text-white min-h-screen font-sans">
      {/* Header */}
      <header className="text-center py-10 border-b border-gray-700">
        <h1 className="text-4xl font-bold text-blue-500">SosyalBoost</h1>
        <p className="text-gray-300 mt-2">TikTok & Instagram için Güvenilir Sosyal Medya Hizmetleri</p>
      </header>

      {/* Services */}
      <section className="py-10 px-4 md:px-20">
        <h2 className="text-2xl font-semibold mb-6 text-white">Hizmetlerimiz</h2>

        {/* TikTok */}
        <div className="mb-10">
          <h3 className="text-xl text-pink-400 mb-2">TikTok Hizmetleri</h3>
          <div className="bg-gray-900 p-4 rounded-2xl mb-4">
            <p className="text-lg">10K İzlenme - <span className="font-semibold text-green-400">75₺</span></p>
            <Button className="mt-2 bg-green-600 hover:bg-green-700" onClick={() => window.open("https://wa.me/905435042073?text=Merhaba%2C%2010K%20TikTok%20izlenme%20paketiyle%20ilgileniyorum.", "_blank")}>WhatsApp'tan Ulaş</Button>
          </div>
          <div className="bg-gray-900 p-4 rounded-2xl">
            <p className="text-lg">Beğeni & Kaydetmeler - <span className="font-semibold text-yellow-400">En uygun fiyattan</span></p>
            <Button className="mt-2 bg-green-600 hover:bg-green-700" onClick={() => window.open("https://wa.me/905435042073?text=Merhaba%2C%20TikTok%20beğeni%20ve%20kaydetme%20paketleriyle%20ilgileniyorum.", "_blank")}>WhatsApp'tan Ulaş</Button>
          </div>
        </div>

        {/* Instagram */}
        <div>
          <h3 className="text-xl text-pink-400 mb-2">Instagram Hizmetleri</h3>
          <div className="bg-gray-900 p-4 rounded-2xl mb-4">
            <p className="text-lg">500 Gerçek Takipçi - <span className="font-semibold text-green-400">120₺</span></p>
            <Button className="mt-2 bg-green-600 hover:bg-green-700" onClick={() => window.open("https://wa.me/905435042073?text=Merhaba%2C%20500%20gerçek%20Instagram%20takipçi%20paketiyle%20ilgileniyorum.", "_blank")}>WhatsApp'tan Ulaş</Button>
          </div>
          <div className="bg-gray-900 p-4 rounded-2xl">
            <p className="text-lg">1000 Gerçek Türk Takipçi - <span className="font-semibold text-green-400">215₺</span></p>
            <Button className="mt-2 bg-green-600 hover:bg-green-700" onClick={() => window.open("https://wa.me/905435042073?text=Merhaba%2C%201000%20gerçek%20Türk%20takipçi%20paketiyle%20ilgileniyorum.", "_blank")}>WhatsApp'tan Ulaş</Button>
          </div>
        </div>
      </section>

      {/* Contact */}
      <footer className="text-center py-10 border-t border-gray-700">
        <p className="text-gray-400">İletişim: <a href="https://wa.me/905435042073" className="text-blue-400 hover:underline">+90 543 504 20 73</a></p>
        <p className="text-gray-500 mt-2 text-sm">© 2025 SosyalBoost. Tüm hakları saklıdır.</p>
      </footer>
    </div>
  );
}
